package com.Game.main;

public enum Layer {
	
	Environment,
	Player,
	Camera,
	Enemy,
	Static,
	Dynamic,
	Ground
	
}
