package com.Game.main;

public class Constants {
	public static double gravity = 33;
}
